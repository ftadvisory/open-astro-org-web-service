installation: sudo setup.py install

running the program: openastro

dependencies: python-gtk2 python-dateutil python-gnome2-desktop (>= 2.16) /* for python bindings to librsvg, pyrsvg / python-cairo (>= 1.2.0) librsvg2-bin (for rsvg-convert binary) imagemagick / export features / pyswisseph / http://pyswisseph.atarax.org/ */ openastro.org-data